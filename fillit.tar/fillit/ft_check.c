#include "fillit.h"

int		ft_check(t_square *square, t_tetri *tetri)
{
	size_t	shifter;

	shifter = 28 - tetri->x;
	if ((square->grid[tetri->y] & (((unsigned int)tetri->bits.row0) << shifter))
			|| (square->grid[tetri->y + 1]
			& (((unsigned int)tetri->bits.row1) << shifter))
			|| (square->grid[tetri->y + 2]
			& (((unsigned int)tetri->bits.row2) << shifter))
			|| (square->grid[tetri->y + 3]
			& (((unsigned int)tetri->bits.row3) << shifter)))
		return (0);
	square->grid[tetri->y] ^= ((unsigned int)tetri->bits.row0) << shifter;
	square->grid[tetri->y + 1] ^= ((unsigned int)tetri->bits.row1) << shifter;
	square->grid[tetri->y + 2] ^= ((unsigned int)tetri->bits.row2) << shifter;
	square->grid[tetri->y + 3] ^= ((unsigned int)tetri->bits.row3) << shifter;
	return (1);
}

void	ft_uncheck(t_square *square, t_tetri *tetri)
{
	size_t	shifter;

	shifter = 28 - tetri->x;
	square->grid[tetri->y] ^= ((unsigned int)tetri->bits.row0) << shifter;
	square->grid[tetri->y + 1] ^= ((unsigned int)tetri->bits.row1) << shifter;
	square->grid[tetri->y + 2] ^= ((unsigned int)tetri->bits.row2) << shifter;
	square->grid[tetri->y + 3] ^= ((unsigned int)tetri->bits.row3) << shifter;
}
