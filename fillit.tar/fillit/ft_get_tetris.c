#include "fillit.h"
#include <stdio.h>

static void		ft_read_tetri(char **content, t_tetri *tetri)
{
	size_t	i;
	size_t	j;
	size_t	k;

	k = 0;
	i = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			if (**content == '#')
			{
				tetri->blocks[k].x = j;
				tetri->blocks[k].y = i;
				++k;
			}
			++(*content);
			++j;
		}
		++(*content);
		++i;
	}
	++(*content);
}

static void		ft_normalize(t_tetri *tetri)
{
	t_block	min;
	t_block	max;
	int		i;

	min.x = 4 - 1;
	min.y = 4 - 1;
	max.x = 0;
	max.y = 0;
	i = -1;
	while (++i < 4)
	{
		min.x = tetri->blocks[i].x < min.x ? tetri->blocks[i].x : min.x;
		min.y = tetri->blocks[i].y < min.y ? tetri->blocks[i].y : min.y;
		max.x = tetri->blocks[i].x > max.x ? tetri->blocks[i].x : max.x;
		max.y = tetri->blocks[i].y > max.y ? tetri->blocks[i].y : max.y;
	}
	//printf("min.x = %zu\t", min.x);
	//printf("min.y = %zu\n", min.y);
	tetri->width = max.x - min.x + 1;
	tetri->height = max.y - min.y + 1;
	i = -1;
	while (++i < 4)
	{
		tetri->blocks[i].x -= min.x;
		tetri->blocks[i].y -= min.y;
		//printf("tetri->blocks[%d].x = %zu\t", i, tetri->blocks[i].x);
		//printf("tetri->blocks[%d].y = %zu\n", i, tetri->blocks[i].y);
	}
}

static void		ft_init_bits(t_tetri *tetri)
{
	size_t	i;

	tetri->bits.row0 = 0;
	tetri->bits.row1 = 0;
	tetri->bits.row2 = 0;
	tetri->bits.row3 = 0;
	i = 0;
	while (i < 4)
	{
		//printf("tetri->bits.row0 | 0b1000 >> tetri->blocks[%zu].x = %d\n", i, (tetri->bits.row0 | 0b1000 >> tetri->blocks[i].x));
		if (tetri->blocks[i].y == 0)
			tetri->bits.row0 |= 0b1000 >> tetri->blocks[i].x;
		else if (tetri->blocks[i].y == 1)
			tetri->bits.row1 |= 0b1000 >> tetri->blocks[i].x;
		else if (tetri->blocks[i].y == 2)
			tetri->bits.row2 |= 0b1000 >> tetri->blocks[i].x;
		else if (tetri->blocks[i].y == 3)
			tetri->bits.row3 |= 0b1000 >> tetri->blocks[i].x;
		++i;
	}
	//printf("\n");
}

static void		ft_find_last(t_tetri **tetris, size_t i)
{
	size_t	j;

	tetris[i]->last = NULL;
	j = i;
	while (j-- > 0)
	{
		if (tetris[i]->bits.row0 == tetris[j]->bits.row0
			&& tetris[i]->bits.row1 == tetris[j]->bits.row1
			&& tetris[i]->bits.row2 == tetris[j]->bits.row2
			&& tetris[i]->bits.row3 == tetris[j]->bits.row3)
		{
			tetris[i]->last = tetris[j];
			return ;
		}
	}
}

size_t			ft_get_tetris(char *content, size_t nbr_tetris,
															t_tetri **tetris)
{
	size_t	i;
	size_t	j;

	i = 0;
	while (i < nbr_tetris)
	{
		if (!(tetris[i] = (t_tetri *)malloc(sizeof(**tetris))))
		{
			j = 0;
			while (j < i)
				free(tetris[j++]);
			return (0);
		}
		ft_read_tetri(&content, tetris[i]);
		tetris[i]->x = 0;
		tetris[i]->y = 0;
		ft_normalize(tetris[i]);
		ft_init_bits(tetris[i]);
		ft_find_last(tetris, i);
		++i;
	}
	return (i);
}
