#include "fillit.h"

void	ft_destroy_tetris(size_t nbr_tetris, t_tetri **tetris)
{
	size_t	i;

	i = 0;
	while (i < nbr_tetris)
	{
		free(tetris[i]);
		++i;
	}
	free(tetris);
}
