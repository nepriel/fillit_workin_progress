#include "fillit.h"

int		ft_move(t_square *square, t_tetri *tetri)
{
	if (tetri->x + tetri->width < square->size)
		++(tetri->x);
	else if (tetri->y + tetri->height < square->size)
	{
		tetri->x = 0;
		++(tetri->y);
	}
	else
		return (0);
	return (1);
}

int		ft_solve_one(t_square *square, size_t nbr_tetris,
						t_tetri **tetris, size_t i)
{
	if (i >= nbr_tetris)
		return (1);
	if (tetris[i]->last)
	{
		tetris[i]->x = tetris[i]->last->x;
		tetris[i]->y = tetris[i]->last->y;
	}
	else
	{
		tetris[i]->x = 0;
		tetris[i]->y = 0;
	}
	while (1)
	{
		if (ft_check(square, tetris[i]))
		{
			if (ft_solve_one(square, nbr_tetris, tetris, i + 1))
				return (1);
			ft_uncheck(square, tetris[i]);
		}
		if (!ft_move(square, tetris[i]))
			return (0);
	}
}

void	ft_solve(t_square *square, size_t nbr_tetris, t_tetri **tetris)
{
	while (!ft_solve_one(square, nbr_tetris, tetris, 0))
		++(square->size);
}
