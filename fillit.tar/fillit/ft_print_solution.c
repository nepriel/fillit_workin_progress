#include "fillit.h"

static size_t	ft_index(t_square *square, t_tetri *tetri, size_t block)
{
	return (tetri->blocks[block].x + tetri->x
			+ (tetri->blocks[block].y + tetri->y) * (square->size + 1));
}

void			ft_print_solution(t_square *square, size_t nbr_tetris,
									t_tetri **tetris)
{
	char	str[square->size * (square->size + 1)];
	size_t	len;
	size_t	i;
	size_t	block;

	len = square->size * (square->size + 1);
	i = 0;
	while (i < len)
	{
		str[i] = (i % (square->size + 1) == square->size) ? '\n' : '.';
		++i;
	}
	i = 0;
	while (i < nbr_tetris)
	{
		block = 0;
		while (block < 4)
		{
			str[ft_index(square, tetris[i], block)] = 'A' + i;
			block++;
		}
		i++;
	}
	write(1, str, len);
}
