#ifndef FILLIT_H
# define FILLIT_H

# define MAX_FILE_SIZE 545
# define GRID_SIZE 22

# include <unistd.h>
# include <sys/types.h>
# include <fcntl.h>
# include <stdlib.h>

typedef struct	s_block
{
	size_t	x;
	size_t	y;
}				t_block;

typedef struct	s_bits
{
	unsigned char	row0 : 4;
	unsigned char	row1 : 4;
	unsigned char	row2 : 4;
	unsigned char	row3 : 4;
}				t_bits;

typedef struct	s_tetri
{
	t_bits			bits;
	size_t			x;
	size_t			y;
	struct s_tetri	*last;
	size_t			width;
	size_t			height;
	t_block			blocks[4];
}				t_tetri;

typedef struct	s_square
{
	unsigned int	grid[GRID_SIZE];
	size_t			size;
}				t_square;

size_t			ft_read_file(char *path, char **content);
size_t			ft_read_content(char *content, size_t size);
size_t			ft_get_tetris(char *content, size_t nbr_tetris,
								t_tetri **tetris);
void			ft_init_square(t_square *square, size_t count,
								t_tetri **tetris);
int				ft_check(t_square *square, t_tetri *tetri);
void			ft_uncheck(t_square *square, t_tetri *tetri);
int				ft_move(t_square *square, t_tetri *tetri);
void			ft_solve(t_square *square, size_t nbr_tetris, t_tetri **tetris);
void			ft_print_solution(t_square *square, size_t nbr_tetris,
									t_tetri **tetris);
void			ft_destroy_tetris(size_t nbr_tetris, t_tetri **tetris);

#endif
